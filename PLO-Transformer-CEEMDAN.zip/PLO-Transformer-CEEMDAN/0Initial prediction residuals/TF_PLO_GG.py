"""
====================  依赖库与环境准备  ====================
"""
import random
import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn import preprocessing
import warnings
import math
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader

# 导入PLO优化器
from PLO import PLO

# 设置随机种子，确保结果可复现
random.seed(42)
np.random.seed(42)
torch.manual_seed(42)

warnings.filterwarnings("ignore")


"""
====================  简易注意力机制  ====================
"""
class MyAttention(nn.Module):
    def __init__(self, d_model):
        super(MyAttention, self).__init__()
        self.d_model = d_model
        self.proj_q = nn.Linear(d_model, d_model)
        self.proj_k = nn.Linear(d_model, d_model)
        self.proj_v = nn.Linear(d_model, d_model)

    def forward(self, q, k, v, attn_mask=None):
        Q = self.proj_q(q)
        K = self.proj_k(k)
        V = self.proj_v(v)
        
        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.d_model)
        
        if attn_mask is not None:
            scores = scores.masked_fill(attn_mask == 0, -1e9)
            
        attn = F.softmax(scores, dim=-1)
        out = torch.matmul(attn, V)
        
        return out, attn


"""
====================  编码器部分：Encoder、EncoderLayer  ====================
"""
class EncoderLayer(nn.Module):
    def __init__(self, attention, d_model, d_ff=None, dropout=0.2, activation="relu"):
        super(EncoderLayer, self).__init__()
        d_ff = d_ff or 4 * d_model
        self.attention = attention
        self.linear1 = nn.Linear(d_model, d_ff)
        self.linear2 = nn.Linear(d_ff, d_model)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = F.relu if activation == "relu" else F.gelu

    def forward(self, x, attn_mask=None):
        new_x, attn = self.attention(x, x, x, attn_mask=attn_mask)
        x = x + self.dropout(new_x)
        
        y = self.norm1(x)
        y = self.dropout(self.activation(self.linear1(y)))
        y = self.dropout(self.linear2(y))
        y = self.norm2(x + y)
        return y, attn

class Encoder(nn.Module):
    def __init__(self, attn_layers, norm_layer=None):
        super(Encoder, self).__init__()
        self.attn_layers = nn.ModuleList(attn_layers)
        self.norm = norm_layer

    def forward(self, x, attn_mask=None):
        attns = []
        for layer in self.attn_layers:
            x, attn = layer(x, attn_mask=attn_mask)
            attns.append(attn)
        if self.norm is not None:
            x = self.norm(x)
        return x, attns


"""
====================  解码器部分：Decoder、DecoderLayer  ====================
"""
class DecoderLayer(nn.Module):
    def __init__(self, self_attention, cross_attention, d_model, d_ff=None, dropout=0.2, activation="relu"):
        super(DecoderLayer, self).__init__()
        d_ff = d_ff or 4 * d_model
        self.self_attention = self_attention
        self.cross_attention = cross_attention
        self.linear1 = nn.Linear(d_model, d_ff)
        self.linear2 = nn.Linear(d_ff, d_model)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.norm3 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = F.relu if activation == "relu" else F.gelu

    def forward(self, x, cross, x_mask=None, cross_mask=None):
        new_x, _ = self.self_attention(x, x, x, attn_mask=x_mask)
        x = x + self.dropout(new_x)
        x = self.norm1(x)

        new_x, _ = self.cross_attention(x, cross, cross, attn_mask=cross_mask)
        x = x + self.dropout(new_x)
        x = self.norm2(x)

        y = x
        y = self.dropout(self.activation(self.linear1(y)))
        y = self.dropout(self.linear2(y))
        x = self.norm3(x + y)

        return x

class Decoder(nn.Module):
    def __init__(self, layers, norm_layer=None, projection=None):
        super(Decoder, self).__init__()
        self.layers = nn.ModuleList(layers)
        self.norm = norm_layer
        self.projection = projection

    def forward(self, x, cross, x_mask=None, cross_mask=None):
        for layer in self.layers:
            x = layer(x, cross, x_mask=x_mask, cross_mask=cross_mask)
        if self.norm is not None:
            x = self.norm(x)
        if self.projection is not None:
            x = self.projection(x)
        return x


"""
====================  完整模型：Encoder + Decoder  ====================
"""
class MyTransformerModel(nn.Module):
    def __init__(self, d_model=32, num_enc_layers=4, num_dec_layers=4):
        super(MyTransformerModel, self).__init__()
        
        self.input_proj = nn.Linear(d_model, d_model * 2)
        self.input_dropout = nn.Dropout(0.2)
        
        enc_layers = []
        for _ in range(num_enc_layers):
            layer = EncoderLayer(
                attention=MyAttention(d_model * 2),
                d_model=d_model * 2,
                d_ff=d_model * 8,
                dropout=0.2,
                activation="relu"
            )
            enc_layers.append(layer)
        self.encoder = Encoder(
            attn_layers=enc_layers,
            norm_layer=nn.LayerNorm(d_model * 2)
        )
        
        dec_layers = []
        for _ in range(num_dec_layers):
            layer = DecoderLayer(
                self_attention=MyAttention(d_model * 2),
                cross_attention=MyAttention(d_model * 2),
                d_model=d_model * 2,
                d_ff=d_model * 8,
                dropout=0.2,
                activation="relu"
            )
            dec_layers.append(layer)
        self.decoder = Decoder(
            layers=dec_layers,
            norm_layer=nn.LayerNorm(d_model * 2)
        )
        
        self.pre_proj = nn.Linear(d_model * 2, d_model)
        self.final_proj = nn.Linear(d_model, 1)
        self.output_dropout = nn.Dropout(0.2)

    def forward(self, enc_in, dec_in):
        enc_in = self.input_dropout(self.input_proj(enc_in))
        dec_in = self.input_dropout(self.input_proj(dec_in))
        
        enc_out, _ = self.encoder(enc_in)
        dec_out = self.decoder(dec_in, enc_out)
        
        out = dec_out[:, -1, :]
        out = self.output_dropout(F.gelu(self.pre_proj(out)))
        out = self.final_proj(out)
        return out


"""
====================  数据处理函数  ====================
"""
def data_transform(t, df):
    a = df.shape[1] * t
    b = len(df) - t
    x = np.zeros((b, a + 1))
    for i in range(b):
        feats = df.iloc[i : i + t, :].values.flatten()
        target = df.iloc[i + t, -1]
        x[i, :-1] = feats
        x[i, -1] = target
    return x

def anti_difference(pred_diff, last_real_segment):
    real = []
    for i in range(len(pred_diff)):
        real_value = pred_diff[i] + last_real_segment[i]
        real.append(real_value)
    return real


"""
====================  读取与预处理数据  ====================
"""
df = pd.read_csv('dataGG.csv', index_col='date')
data_diff = df.diff().dropna()
df_tr = data_transform(t=3, df=data_diff)

scale_x = preprocessing.StandardScaler()
scale_y = preprocessing.StandardScaler()
X_ = scale_x.fit_transform(df_tr[:, :-1])
y = scale_y.fit_transform(df_tr[:, -1].reshape(-1, 1))

# 划分数据集 - 新的划分逻辑
total_samples = len(df_tr)

# 第一步：划分训练验证集(80%)和测试集(20%)
train_val_size = int(total_samples * 0.8)
test_size = total_samples - train_val_size

# 第二步：将训练验证集划分为训练集(80%)和验证集(20%)
train_size = int(train_val_size * 0.8)
val_size = train_val_size - train_size

# 划分数据
x_train = X_[:train_size, :]
y_train = y[:train_size]

x_val = X_[train_size:train_val_size, :]
y_val = y[train_size:train_val_size]

x_test = X_[train_val_size:, :]
y_test = y[train_val_size:]

print(f"数据集划分: 总样本={total_samples}, 训练集={train_size}({train_size/total_samples:.1%}), 验证集={val_size}({val_size/total_samples:.1%}), 测试集={test_size}({test_size/total_samples:.1%})")

# 转 PyTorch Tensor
x_train_torch = torch.from_numpy(x_train).float()
y_train_torch = torch.from_numpy(y_train).float()
x_val_torch = torch.from_numpy(x_val).float()
y_val_torch = torch.from_numpy(y_val).float()
x_test_torch = torch.from_numpy(x_test).float()
y_test_torch = torch.from_numpy(y_test).float()

"""
====================  构造 Encoder/Decoder 输入  ====================
"""
seq_len = 3
d_model = x_train_torch.shape[1] // seq_len

enc_in_train = x_train_torch.view(-1, seq_len, d_model)
dec_in_train = x_train_torch.view(-1, seq_len, d_model)

enc_in_val = x_val_torch.view(-1, seq_len, d_model)
dec_in_val = x_val_torch.view(-1, seq_len, d_model)

enc_in_test = x_test_torch.view(-1, seq_len, d_model)
dec_in_test = x_test_torch.view(-1, seq_len, d_model)

# 创建数据加载器
train_dataset = TensorDataset(enc_in_train, dec_in_train, y_train_torch)
train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)

val_dataset = TensorDataset(enc_in_val, dec_in_val, y_val_torch)
val_loader = DataLoader(val_dataset, batch_size=16, shuffle=False)

"""
====================  定义模型  ====================
"""
model = MyTransformerModel(
    d_model=d_model,
    num_enc_layers=4,
    num_dec_layers=4
)

criterion = nn.MSELoss()

"""
====================  训练模型（使用PLO极光优化算法）  ====================
"""
# 设置PLO算法参数
num_particles = 50  # 粒子数量
max_iter = 100      # 最大迭代次数
patience = 20       # 早停耐心值
learning_rate = 1e-4  # 学习率（从1e-5提高到1e-4）

# 创建回调函数来打印每次迭代的结果
def callback_fn(iteration, current_loss, best_particle):
    if (iteration + 1) % 10 == 0 or iteration == 0:
        print(f"迭代 {iteration + 1}/{max_iter}, 当前最佳损失: {current_loss:.6f}")

# 重写PLO优化器的evaluate方法，使其适应我们特定的模型输入
class CustomPLO(PLO):
    def evaluate(self, params, data_loader):
        """评估参数在数据集上的性能"""
        # 保存原始参数
        original_params = {}
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                original_params[name] = param.clone().detach()
                param.data = params[name].clone()
        
        # 在数据集上评估模型
        self.model.eval()
        total_loss = 0
        
        with torch.no_grad():
            for enc_in, dec_in, target in data_loader:
                outputs = self.model(enc_in, dec_in)
                loss = criterion(outputs, target)
                total_loss += loss.item()
        
        # 恢复原始参数
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                param.data = original_params[name].clone()
        
        return total_loss / len(data_loader)

# 初始化PLO优化器，在初始化时指定粒子数量和最大迭代次数
plo = CustomPLO(
    model=model,
    num_particles=num_particles,
    max_iter=max_iter,
    lr=learning_rate
)

# 使用PLO优化模型
best_loss, best_params = plo.optimize(
    data_loader=train_loader,
    eval_loader=val_loader,
    callback=callback_fn
)
print(f"最终验证集损失: {best_loss:.6f}")


"""
====================  测试并预测  ====================
"""
model.eval()
with torch.no_grad():
    # 预测训练集
    pr_train_torch = model(enc_in_train, dec_in_train)
    # 预测验证集
    pr_val_torch = model(enc_in_val, dec_in_val)
    # 预测测试集
    pr_test_torch = model(enc_in_test, dec_in_test)

# 转换为numpy数组
pr_train = pr_train_torch.numpy()
pr_val = pr_val_torch.numpy()
pr_test = pr_test_torch.numpy()

# 分别对训练集、验证集和测试集进行反标准化
pr_train = scale_y.inverse_transform(pr_train.reshape(-1, 1))
pr_val = scale_y.inverse_transform(pr_val.reshape(-1, 1))
pr_test = scale_y.inverse_transform(pr_test.reshape(-1, 1))

# 分别对三个数据集进行反差分
train_prediction = anti_difference(pr_train, df['X_0'][-len(pr_train) - len(pr_val) - len(pr_test):-len(pr_val) - len(pr_test)].values)
val_prediction = anti_difference(pr_val, df['X_0'][-len(pr_val) - len(pr_test):-len(pr_test)].values)
test_prediction = anti_difference(pr_test, df['X_0'][-len(pr_test):].values)

# 合并训练集、验证集和测试集的预测结果与真实值
all_predictions = np.concatenate([train_prediction, val_prediction, test_prediction])
all_real = df['X_0'][-len(all_predictions):].values

# 确保所有数组都是一维的
all_real_1d = all_real.flatten()
all_predictions_1d = all_predictions.flatten()
dataset_labels = ['Train'] * len(train_prediction) + \
                ['Validation'] * len(val_prediction) + \
                ['Test'] * len(test_prediction)

# 创建包含所有数据的DataFrame
result_df = pd.DataFrame({
    'Real': all_real_1d,
    'Prediction': all_predictions_1d,
    'Dataset': dataset_labels
})

# 保存结果到CSV文件
result_df.to_csv('./TF_PLO_all_results.csv', index=False)

# 绘制完整的预测结果图表
plt.figure(figsize=(12, 6))
plt.plot(all_real, label='真实值', linewidth=2)
plt.plot(all_predictions, label='预测值', linewidth=2, linestyle='--')
plt.legend()
plt.title('TF-PLO模型完整预测结果')
plt.savefig('./TF_PLO_all_prediction.png')
plt.close()