"""
极光优化算法 (Polar Light Optimizer, PLO)
参考论文: Polar Light Optimizer: A Novel Nature-Inspired Metaheuristic Algorithm for Optimization Problems
"""

import numpy as np
import torch
import torch.nn as nn
import random
import copy


class PLO:
    """
    极光优化算法实现
    
    参数:
    - model: 要优化的模型
    - num_particles: 粒子数量
    - max_iter: 最大迭代次数
    - lr: 学习率，控制粒子移动步长
    """
    def __init__(self, model, num_particles=20, max_iter=50, lr=0.01):
        self.model = model
        self.num_particles = num_particles
        self.max_iter = max_iter
        self.lr = lr
        self.particles = []
        self.best_particle = None
        self.best_loss = float('inf')
        
        # 添加搜索范围约束
        self.lb = None  # 搜索下界
        self.ub = None  # 搜索上界
        
        # 初始化参数边界
        self._init_boundaries()
        
    def _init_boundaries(self):
        """初始化参数的搜索范围边界"""
        # 基于初始模型参数设置边界
        params_dict = {}
        for name, param in self.model.named_parameters():
            params_dict[name] = param.clone().detach()
            
        # 设置lb和ub为原始参数值的±0.5范围
        self.lb = {}
        self.ub = {}
        for name, param in params_dict.items():
            self.lb[name] = param - 0.5
            self.ub[name] = param + 0.5
    
    def clip_params(self, params):
        """将参数裁剪到搜索范围内"""
        clipped_params = {}
        for name, param in params.items():
            clipped_params[name] = torch.max(torch.min(param, self.ub[name]), self.lb[name])
        return clipped_params
    
    def init_particles(self):
        """初始化极光粒子群"""
        # 获取模型的初始参数
        initial_params = {}
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                initial_params[name] = param.clone().detach()
        
        # 创建粒子群
        self.particles = []
        for i in range(self.num_particles):
            # 为每个粒子添加不同程度的随机扰动
            particle_params = {}
            for name, param in initial_params.items():
                # 增加初始扰动范围，最大扰动为0.1而不是原来的0.01
                perturbation = torch.randn_like(param) * (0.05 + 0.05 * i / self.num_particles)
                particle_params[name] = param + perturbation
            
            # 裁剪到搜索范围内
            particle_params = self.clip_params(particle_params)
            
            self.particles.append({
                'params': particle_params,
                'velocity': {name: torch.zeros_like(param) for name, param in particle_params.items()},
                'best_params': copy.deepcopy(particle_params),
                'best_loss': float('inf')
            })
    
    def evaluate(self, params, data_loader):
        """评估参数在数据集上的性能"""
        # 保存原始参数
        original_params = {}
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                original_params[name] = param.clone().detach()
                param.data = params[name].clone()
        
        # 在数据集上评估模型
        self.model.eval()
        total_loss = 0
        criterion = nn.MSELoss()
        
        with torch.no_grad():
            for batch in data_loader:
                x, y = batch
                outputs = self.model(x)
                loss = criterion(outputs, y)
                total_loss += loss.item()
        
        # 恢复原始参数
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                param.data = original_params[name].clone()
        
        return total_loss / len(data_loader)
    
    def move_particles(self, data_loader):
        """移动极光粒子"""
        for i, particle in enumerate(self.particles):
            # 更新粒子的最佳位置
            loss = self.evaluate(particle['params'], data_loader)
            if loss < particle['best_loss']:
                particle['best_loss'] = loss
                particle['best_params'] = copy.deepcopy(particle['params'])
            
            # 更新全局最佳位置
            if loss < self.best_loss:
                self.best_loss = loss
                self.best_particle = copy.deepcopy(particle['params'])
                # 采用模型的最优参数
                for name, param in self.model.named_parameters():
                    if param.requires_grad:
                        param.data = self.best_particle[name].clone()
            
            # 模拟极光运动
            for name in particle['params']:
                # 增加随机扰动的强度
                random_factor = torch.randn_like(particle['params'][name]) * 0.2  # 从0.1增加到0.2
                
                # 向全局最佳位置移动
                if self.best_particle is not None:
                    particle['params'][name] = particle['params'][name] + \
                                              self.lr * (self.best_particle[name] - particle['params'][name]) + \
                                              random_factor
                else:
                    particle['params'][name] = particle['params'][name] + random_factor
                
                # 模拟粒子碰撞
                if random.random() < 0.1:  # 增加碰撞概率，从0.05到0.1
                    # 随机选择另一个粒子
                    other_idx = random.randint(0, self.num_particles - 1)
                    while other_idx == i:
                        other_idx = random.randint(0, self.num_particles - 1)
                    
                    # 与另一个粒子交换信息
                    other_particle = self.particles[other_idx]
                    
                    # 碰撞后产生新的位置（增加碰撞后的扰动强度）
                    collision_factor = torch.randn_like(particle['params'][name]) * 0.05  # 从0.01增加到0.05
                    particle['params'][name] = (particle['params'][name] + other_particle['params'][name]) / 2 + collision_factor
            
            # 裁剪参数到搜索范围内
            particle['params'] = self.clip_params(particle['params'])
    
    def optimize(self, data_loader, eval_loader=None, callback=None):
        """优化模型参数"""
        self.init_particles()
        
        best_eval_loss = float('inf')
        patience_counter = 0
        max_patience = 20
        
        for iteration in range(self.max_iter):
            self.move_particles(data_loader)
            
            # 计算当前最佳损失
            current_loss = self.best_loss
            
            # 如果提供了评估数据集，则在评估集上计算损失
            if eval_loader is not None:
                eval_loss = self.evaluate(self.best_particle, eval_loader)
                
                # 早停机制
                if eval_loss < best_eval_loss:
                    best_eval_loss = eval_loss
                    patience_counter = 0
                else:
                    patience_counter += 1
                
                if patience_counter >= max_patience:
                    print(f"早停：在迭代{iteration}中达到最大耐心值")
                    break
            
            # 如果提供了回调函数，则调用它
            if callback is not None:
                callback(iteration, current_loss, self.best_particle)
            
            # 打印当前迭代的信息
            if (iteration + 1) % 10 == 0 or iteration == 0:
                print(f"迭代 {iteration + 1}/{self.max_iter}, 当前最佳损失: {current_loss:.6f}")
        
        # 使用最佳参数更新模型
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                param.data = self.best_particle[name].clone()
        
        return self.best_loss, self.best_particle


# # 使用示例
# if __name__ == "__main__":
#     # 定义一个简单的PyTorch模型用于测试
#     import torch.nn as nn
    
#     class SimpleModel(nn.Module):
#         def __init__(self):
#             super(SimpleModel, self).__init__()
#             self.linear1 = nn.Linear(10, 5)
#             self.linear2 = nn.Linear(5, 1)
            
#         def forward(self, x):
#             x = torch.relu(self.linear1(x))
#             x = self.linear2(x)
#             return x
    
#     # 创建一个简单的测试函数
#     def test_plo():
#         # 生成随机数据
#         X = torch.randn(100, 10)
#         y = torch.randn(100, 1)
        
#         # 初始化模型
#         model = SimpleModel()
        
#         # 定义损失函数
#         criterion = nn.MSELoss()
        
#         # 定义适应度函数
#         def fitness_function(model):
#             with torch.no_grad():
#                 outputs = model(X)
#                 loss = criterion(outputs, y)
#             return loss.item()
        
#         # 初始化PLO优化器
#         plo = PLO(
#             model=model,
#             num_particles=10,
#             max_iter=20,
#             lr=0.01
#         )
        
#         # 运行优化
#         best_fitness = plo.optimize(fitness_function, patience=10)
#         print(f"最终损失: {best_fitness}")
    
#     # 运行测试
#     # test_plo() 