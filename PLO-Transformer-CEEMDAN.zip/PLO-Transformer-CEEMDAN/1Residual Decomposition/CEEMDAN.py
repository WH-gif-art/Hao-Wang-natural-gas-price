# -*- coding: utf-8 -*-
from PyEMD import CEEMDAN,EEMD,EMD,Visualisation
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVR
from sklearn import preprocessing
import random
import warnings
warnings.filterwarnings("ignore")
#EMD-signal                         1.2.3
random.seed(2022)
np.random.seed(2022)

data = pd.read_csv('res_data.csv')
data_ = np.array(data['res']).T

def ceemdan_decompose_res(data):
    random.seed(200)
    np.random.seed(200)

    ceemdan = CEEMDAN()
    ceemdan.random.seed(0)
    ceemdan.ceemdan(data)
    IImfs=[]
    imfs, res = ceemdan.get_imfs_and_residue()
#    #    IImfs即为imf的集合，res即为残差项

    plt.figure(figsize=(12,9))#图像尺寸
    plt.subplots_adjust(hspace=0.1)#subplots子图，hspace用于设置图片与文本左右的距离
    plt.subplot(imfs.shape[0]+2, 1, 1)#plt.subplot(行数，列数，标号)nrows, ncols, index
    plt.plot(data,'r')#x轴 y轴
    
    print(imfs.shape[0])  #5
    for i in range(imfs.shape[0]):
        plt.subplot(imfs.shape[0]+2,1,i+2)
        plt.plot(imfs[i], 'g')
        plt.ylabel("IMF %i" %(i+1))
        plt.locator_params(axis='x', nbins=10)
        # 在函数前必须设置一个全局变量 IImfs=[]
        IImfs.append(imfs[i])
    plt.subplot(imfs.shape[0]+2, 1, imfs.shape[0]+2)
    plt.plot(res,'b')
#    plt.savefig('wl_bg_res.png') 
    plt.savefig('wl_res.png') 
    plt.show()
    
    return IImfs,res

IImfs,res = ceemdan_decompose_res(data_)

df1 = pd.DataFrame()
for i in range(len(IImfs)):
    line = pd.Series(IImfs[i])
    df1 = pd.concat([df1, line.to_frame().T], ignore_index=True)    
df1 = pd.concat([df1, pd.Series(res).to_frame().T], ignore_index=True) 


df2 = pd.DataFrame(df1.values.T, index=df1.columns, columns=df1.index)
#df2.columns = ['Imf1','Imf2','Imf3','Imf4','Imf5','Imf6','Imf7','Imf8','Imf9','Imf10','res']
# df2.columns = ['Imf1','Imf2','Imf3','Imf4','Imf5','Imf6','Imf7','Imf8','Imf9','Imf10','Imf11']
df2.columns = ['Imf1','Imf2','Imf3','Imf4','Imf5','Imf6','Imf7','res']
#df2.columns = ['Imf1','Imf2','Imf3','Imf4']
df2.to_csv('res_ceemdan.csv',sep=',',index=False,header=True) 
#df2.to_csv('./emd.csv',sep=',',index=False,header=True) 
