import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np

# 读取CSV文件
df = pd.read_csv('target.csv')

# 获取真实值和预测值
y_true = df['real']
y_pred = df['pred']

# 计算各项指标
mse = mean_squared_error(y_true, y_pred)
rmse = np.sqrt(mse)
mae = mean_absolute_error(y_true, y_pred)
r2 = r2_score(y_true, y_pred)

# 打印结果
print('评估指标结果：')
print(f'MSE (均方误差): {mse:.4f}')
print(f'RMSE (均方根误差): {rmse:.4f}')
print(f'MAE (平均绝对误差): {mae:.4f}')
print(f'R² (决定系数): {r2:.4f}')

# # 将结果保存到文件
# with open('evaluation_results.txt', 'w', encoding='utf-8') as f:
#     f.write('评估指标结果：\n')
#     f.write(f'MSE (均方误差): {mse:.4f}\n')
#     f.write(f'RMSE (均方根误差): {rmse:.4f}\n')
#     f.write(f'MAE (平均绝对误差): {mae:.4f}\n')
#     f.write(f'R² (决定系数): {r2:.4f}\n') 