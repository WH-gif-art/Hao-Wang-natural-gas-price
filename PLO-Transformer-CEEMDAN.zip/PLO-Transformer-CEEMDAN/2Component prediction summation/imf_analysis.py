import os
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

def analyze_imf_results(folder_path):
    """
    分析IMF1至IMF7结果文件中的Prediction和Real列数据
    
    参数:
    folder_path: 包含IMF结果文件的文件夹路径
    
    返回:
    总预测值序列和总实际值序列
    """
    # 存储每个IMF文件的数据框
    imf_dataframes = []
    
    # 循环读取IMF1至IMF7的结果文件
    for i in range(1, 8):
        file_name = f"Imf{i}_results.csv"  # 假设文件是CSV格式
        file_path = os.path.join(folder_path, file_name)
        
        try:
            # 读取文件
            df = pd.read_csv(file_path)
            
            # 确保文件包含所需的列
            if 'Prediction' in df.columns and 'Real' in df.columns:
                # 保存数据框
                imf_dataframes.append(df)
            else:
                print(f"警告: {file_name} 不包含 'Prediction' 或 'Real' 列")
        except Exception as e:
            print(f"读取 {file_name} 时出错: {e}")
    
    if not imf_dataframes:
        print("错误: 没有找到有效的IMF结果文件")
        return None, None
    
    # 确保所有数据框具有相同的长度
    lengths = [len(df) for df in imf_dataframes]
    if len(set(lengths)) > 1:
        print(f"警告: IMF文件长度不一致: {lengths}")
        # 使用最短的长度
        min_length = min(lengths)
        imf_dataframes = [df.iloc[:min_length] for df in imf_dataframes]
    
    # 初始化总预测值和总实际值序列
    total_prediction = np.zeros(len(imf_dataframes[0]))
    total_real = np.zeros(len(imf_dataframes[0]))
    
    # 累加每个IMF的预测值和实际值
    for df in imf_dataframes:
        total_prediction += df['Prediction'].values
        total_real += df['Real'].values
    
    return total_prediction, total_real

def main():
    # 设置包含IMF结果文件的文件夹路径
    # 获取当前脚本所在的目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    print(f"分析文件夹路径: {current_dir}")
    
    # 分析结果
    pred, real = analyze_imf_results(current_dir)
    
    if pred is None or real is None:
        print("无法计算评估指标，程序退出")
        return
    
    # 计算评估指标
    mse = mean_squared_error(real, pred)
    mae = mean_absolute_error(real, pred)
    r2 = r2_score(real, pred)
    rmse = np.sqrt(mse)
    
    # 打印结果
    print("\n===== IMF分析结果 =====")
    print(f"MSE: {mse:.4f}")
    print(f"MAE: {mae:.4f}")
    print(f"R2: {r2:.4f}")
    print(f"RMSE: {rmse:.4f}")
    
    # 将总预测值和总实际值保存到CSV文件
    comparison_df = pd.DataFrame({
        'Prediction': pred,
        'Real': real
    })
    comparison_df.to_csv("分量和.csv", index=False)
    print("\n总预测值与总实际值已保存至'分量和.csv'")

if __name__ == "__main__":
    main() 